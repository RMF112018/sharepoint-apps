# Deploy & Approve Guide — kmeholding.sharepoint.com

Version: 1.0.0
App: HBI Form Demo (SPFx)
Package: hbi-form-demo-1.0.0.sppkg

## Overview
This guide covers Tenant App Catalog upload, API access approval (if any), tenant-wide toggle guidance, per-site install steps, and rollback.

## Prerequisites
- Tenant admin or App Catalog admin on `kmeholding.sharepoint.com`
- Access to the Tenant App Catalog site
- Package file: `hbi-form-demo-1.0.0.sppkg`

## 1) Upload to Tenant App Catalog (recommended)
1. Navigate to the Tenant App Catalog (e.g., `https://kmeholding.sharepoint.com/sites/AppCatalog`)
2. Open “Apps for SharePoint” library
3. Upload `hbi-form-demo-1.0.0.sppkg`
4. Approve the upload when prompted

[Screenshot placeholder: App Catalog upload]

## 2) API access approval
- This solution requests no additional API permissions. No action is required here.

[Screenshot placeholder: API access panel (none)]

## 3) Deployment scope (tenant-wide vs per-site)
- Default for pilots: per-site installation
  - Rationale: limit blast radius and validate list interactions per site
- Tenant-wide availability is supported (solution uses `skipFeatureDeployment: true`) but not required
  - If enabled, editors can add the web part across sites without per-site app installation

[Screenshot placeholder: deployment dialog]

## 4) Install on a site (per-site pilot)
1. Go to the target site
2. Open Site Contents > “New” > “App” (or “From your organization”)
3. Find “HBI Form Demo” and choose “Add”

[Screenshot placeholder: Add app to site]

## 5) Rollback
- Per-site removal:
  - Site Contents > find the app > “...” > Remove
- Tenant rollback:
  - In App Catalog, remove or replace the `.sppkg` with a prior version
  - If tenant-wide was enabled, disable it and/or retract the app

[Screenshot placeholder: Remove app]

## Reference
- App display name (picker): “HBI Form Demo”
- Solution name: `hbi-form-demo-client-side-solution`
- Solution ID: `804c482d-6f49-4e5f-bec6-eeeef567ca5a`
